/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto.pkg1;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Descripcion extends JFrame {

    Destino miDest = new Destino();

    public Descripcion() {
        setSize(500, 500); //tamano ventana 

        setDefaultCloseOperation(EXIT_ON_CLOSE); // Termina ventana
        setTitle("Reservacion");
        setLocationRelativeTo(null); // ventana en centro 

    }

    public void initComponents() {
        JPanel panel = new JPanel(); // crea panel
        panel.setLayout(null);
        this.getContentPane().add(panel);
        System.out.println(miDest.dest);

        if (null != miDest.dest) {
            switch (miDest.dest) {
                //fin if
                case "Francia":
                    JLabel etiqueta = new JLabel();
                    etiqueta.setText("Nombre pais: " + miDest.mipais1.getNombre());
                    etiqueta.setBounds(50, 10, 200, 100);
                    
                     JLabel etiqueta2 = new JLabel();
                    etiqueta2.setText("Precio por dia: " + miDest.mipais1.getPrecio());
                    etiqueta2.setBounds(50, 40, 220, 100);
                    
                     JLabel etiqueta3 = new JLabel();
                    etiqueta3.setText("Descripcion: " + miDest.mipais1.getDescripcion());
                    etiqueta3.setBounds(50, 80, 500, 100);
                    
                    panel.add(etiqueta);
                    panel.add(etiqueta2);
                    panel.add(etiqueta3);
                    break;
                
                case "Belgica":
                 JLabel etiqueta4 = new JLabel();
                    etiqueta4.setText("Nombre pais: " + miDest.mipais2.getNombre());
                    etiqueta4.setBounds(50, 10, 200, 100);
                    
                     JLabel etiqueta5 = new JLabel();
                    etiqueta5.setText("Precio por dia: " + miDest.mipais2.getPrecio());
                    etiqueta5.setBounds(50, 40, 220, 100);
                    
                     JLabel etiqueta6 = new JLabel();
                    etiqueta6.setText("Descripcion: " + miDest.mipais2.getDescripcion());
                    etiqueta6.setBounds(50, 80, 500, 100);
                    
                    panel.add(etiqueta4);
                    panel.add(etiqueta5);
                    panel.add(etiqueta6);
                    break;
                //fin else
                case "Alemania":
                JLabel etiqueta7 = new JLabel();
                    etiqueta7.setText("Nombre pais: " + miDest.mipais3.getNombre());
                    etiqueta7.setBounds(50, 10, 200, 100);
                    
                     JLabel etiqueta8 = new JLabel();
                    etiqueta8.setText("Precio por dia: " + miDest.mipais3.getPrecio());
                    etiqueta8.setBounds(50, 40, 220, 100);
                    
                     JLabel etiqueta9 = new JLabel();
                    etiqueta9.setText("Descripcion: " + miDest.mipais3.getDescripcion());
                    etiqueta9.setBounds(50, 80, 500, 100);
                    
                    panel.add(etiqueta7);
                    panel.add(etiqueta8);
                    panel.add(etiqueta9);
                    break;
                //fin else
                case "Suiza":
                 JLabel etiqueta10 = new JLabel();
                    etiqueta10.setText("Nombre pais: " + miDest.mipais4.getNombre());
                    etiqueta10.setBounds(50, 10, 200, 100);
                    
                     JLabel etiqueta11= new JLabel();
                    etiqueta11.setText("Precio por dia: " + miDest.mipais4.getPrecio());
                    etiqueta11.setBounds(50, 40, 220, 100);
                    
                     JLabel etiqueta12 = new JLabel();
                    etiqueta12.setText("Descripcion: " + miDest.mipais4.getDescripcion());
                    etiqueta12.setBounds(50, 80, 500, 100);
                    
                    panel.add(etiqueta10);
                    panel.add(etiqueta11);
                    panel.add(etiqueta12);
                    break;
                //fin else
                case "Egipto":
               JLabel etiqueta13 = new JLabel();
                    etiqueta13.setText("Nombre pais: " + miDest.mipais5.getNombre());
                    etiqueta13.setBounds(50, 10, 200, 100);
                    
                     JLabel etiqueta14= new JLabel();
                    etiqueta14.setText("Precio por dia: " + miDest.mipais5.getPrecio());
                    etiqueta14.setBounds(50, 40, 220, 100);
                    
                     JLabel etiqueta15 = new JLabel();
                    etiqueta15.setText("Descripcion: " + miDest.mipais5.getDescripcion());
                    etiqueta15.setBounds(50, 80, 500, 100);
                    
                    panel.add(etiqueta13);
                    panel.add(etiqueta14);
                    panel.add(etiqueta15);
                    break;
                default:
                    break;
                //fin else            }
       }
   }
    }
}
