/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto.pkg1;

import javax.swing.JOptionPane;

/**
 *
 * @author aaron
 */
public class Reserva {

    public String vector[] = new String[7];

    public String[] llenaV() {

        for (int i = 0; i <= 7; i++) {
            switch (i) {
                //fin if
                case 0:
                    vector[i] = JOptionPane.showInputDialog("ingrese Pasaporte ");
                    break;
                case 1:
                    vector[i] = JOptionPane.showInputDialog("Ingrese Nombre ");
                    break;
                case 2:
                    vector[i] = JOptionPane.showInputDialog("Ingrese Apellido ");
                    break;
                case 3:
                    vector[i] = JOptionPane.showInputDialog("Ingrese Edad ");
                    break;
                case 4:
                    vector[i] = JOptionPane.showInputDialog("Ingrese correo ");
                    break;
                case 5:
                    vector[i] = JOptionPane.showInputDialog("Ingrese Celular ");
                    break;
                case 6:
                    vector[i] = JOptionPane.showInputDialog("Ingrese Usuario ");
                    break;
                default:
                    break;
            }

        }//fin for
       return vector;
    }//fin llenaV

    
}//fin Clase
