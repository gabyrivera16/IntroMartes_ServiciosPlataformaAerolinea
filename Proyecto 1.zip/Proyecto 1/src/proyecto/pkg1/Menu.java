/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto.pkg1;

import javax.swing.JOptionPane;

/**
 *
 * @author aaron
 */
public class Menu {

    Aeropuerto miAeropuerto = new Aeropuerto();
    Checkin miCheckin = new Checkin();

    // Agregar desitno
    public void muestraMenu() {

        String[] opciones = {
            "Ver Destinos y Reservar viajes",
            "Checkin y Seleccionar Aeropuerto"
        };

        //metodos
        String seleccion = (String) JOptionPane.showInputDialog(null, "Seleccione el aeropuerto", "Aeropuerto", JOptionPane.DEFAULT_OPTION, null, opciones, opciones[0]);
        System.out.println("La elecion es: " + seleccion);

        if ("Ver Destinos y Reservar viajes".equals(seleccion)) {

            Destino miDestino = new Destino();
            miDestino.preguntaPais();
            miDestino.haces();
            miDestino.calcPago();

            Muestra2 miMuestra = new Muestra2();
            miMuestra.setVisible(true);
            miMuestra.initComponents();

        } else if ("Checkin y Seleccionar Aeropuerto".equals(seleccion)) {
            miAeropuerto.despliegaInfo();
            miCheckin.digiteDatos();
        }

    }//fin muestraMenu

}
