/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto.pkg1;

import javax.swing.JOptionPane;

/**
 *
 * @author aaron
 */
public class Destino {

    static String dest;
    int total = 0;
    int cantDias;

   

    String[] paises = {
        "Francia",
        "Belgica",
        "Alemania",
        "Suiza",
        "Egipto"
    };

    Pais mipais1 = new Pais(paises[0], 1000, "Conocido como el pais del amor");
    Pais mipais2 = new Pais(paises[1], 2000, "Conocido por sus ciudades medievales, su arquitectura renacentista y las sedes centrales de la Unión Europea y la OTAN.");
    Pais mipais3 = new Pais(paises[2], 3000, "Es un país de Europa occidental con un paisaje de bosques, ríos, cadenas montañosas y playas en el mar del Norte");
    Pais mipais4 = new Pais(paises[3], 4000, "País montañoso de Europa Central, con varios lagos, aldeas y las altas cimas de los Alpes");
    Pais mipais5 = new Pais(paises[4], 52000, "país que une el noreste de África con Medio Oriente, data del período de los faraones");

    public void preguntaPais() {

        dest = (String) JOptionPane.showInputDialog(null, "Seleccione el pais que desea visitar", "Pais", JOptionPane.DEFAULT_OPTION, null, paises, paises[0]);
        System.out.println("Destino elegido: " + dest);

    }//fin preguntaPais

    public void haces() {
        int resp = JOptionPane.showConfirmDialog(null, "Desea saber informacion sobre el pais a visitar? ", "Informacion", JOptionPane.YES_NO_OPTION);
        if (resp == 0) {
            Descripcion punto = new Descripcion();
            punto.setVisible(true);
            punto.initComponents();
           

        }//fin if
        else {
            preguntaDias();

        }//fin else

    }

    public void preguntaDias() {

        String dias = JOptionPane.showInputDialog("Cuantos dias se va a viajar?");
        cantDias = Integer.parseInt(dias);

    }//fin preguntDias

    public void calcPago() {

        int precio;
        int descuento;

        switch (dest) {
            case "Francia":
                precio = mipais1.getPrecio();
                descuento = 500;
                total = (precio - descuento) * cantDias;
                System.out.println("Total a pagar: " + total);
                break;
            case "Belgica":
                precio = mipais2.getPrecio();
                descuento = 250;
                total = (precio - descuento) * cantDias;
                System.out.println("Total a pagar: " + total);
                break;
            case "Alemania":
                precio = mipais3.getPrecio();
                total = precio * cantDias;
                System.out.println("Total a pagar: " + total);
                break;
            case "Suiza":
                precio = mipais4.getPrecio();
                total = precio * cantDias;
                System.out.println("Total a pagar: " + total);
                break;
            case "Egipto":
                precio = mipais5.getPrecio();
                total = precio * cantDias;
                System.out.println("Total a pagar: " + total);
                break;
        }//fin switch

    }//fin pago

}//fin clase destino

