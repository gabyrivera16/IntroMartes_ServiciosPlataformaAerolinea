/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto.pkg1;

/**
 *
 * @author aaron
 */
import javax.swing.JOptionPane;

public class Aeropuerto {

    //Atributos
    String nombreaero;
    String paisaero;
    String ubicacionaero;

    //constructor
    public void Aeropuerto() {

    }

    String[] aeropuertos = {
        "Juan Santamaria",
        "Changi",
        "Aeropuerto de Hong Kong",
        "Aeropuerto de Munich",
        "Heathrow"
    };

    //metodos
    public void despliegaInfo() {

        JOptionPane.showMessageDialog(null, "Ingresa información del aeropuerto");

        nombreaero = (String) JOptionPane.showInputDialog(null, "Seleccione el aeropuerto", "Aeropuerto", JOptionPane.DEFAULT_OPTION, null, aeropuertos, aeropuertos[0]);
        System.out.println("El nombre del aeropuerto es:" + nombreaero);

        paisaero = JOptionPane.showInputDialog("Ingrese el pais donde se encuentra el aeropuerto:");
        System.out.println("El aeropuerto se encuentra en el pais:" + paisaero);

        ubicacionaero = JOptionPane.showInputDialog("Ingrese la ubicacion del aeropueto:");
        System.out.println("El aeropuerto se encuentra en:" + ubicacionaero);

    }//fin despliegaInfo

}//fin aeropuerto
