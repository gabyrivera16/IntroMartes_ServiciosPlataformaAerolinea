/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto.pkg1;

/**
 *
 * @author aaron
 */
import javax.swing.JOptionPane;
public class Checkin {
    
    int codigo;
    int tiquete;
    int fecha;
    int opcion;
    int frecuente;
   
        
    public void digiteDatos(){
        
        JOptionPane.showMessageDialog(null, "Ingresa informacion Checkin");
      
         do{
             opcion =Integer.parseInt(JOptionPane.showInputDialog("Ingrese cual opcion desea realizar" +" n1.Usar codigo de reserva / n2.Usar mi numero de tiquete electronico / n3.Usar mi numero de viajero frecuente / n5.Salir"));
         
          System.out.println("Opcion:" + opcion);
             
             switch(opcion){
             case 1: //usar codigo de reserva
                 codigo =Integer.parseInt(JOptionPane.showInputDialog("Digite el codigo de reserva"));         
                 
                 System.out.println("El código es:" + codigo);        
                 break;
             case 2:  //Usar tiquete electronico
      
                 tiquete = Integer.parseInt(JOptionPane.showInputDialog("Digite numero de tiquete electronico:"));
                 System.out.println("Tiquete electronico: "+ tiquete);
                 break;
             case 3: //Numero de cliente frecuente
                 
                 System.out.println("Digite el numero de cliente frecuente:");
                 frecuente = Integer.parseInt(JOptionPane.showInputDialog("Digite numero de cliente frecuente:"));
                 System.out.println("Cliente Frecuente: " + frecuente);
                break;
             
             default:
                 System.out.println("La opcion no existe");
                 
         }//fin switch
         
     } while(opcion!=0);
        
    }//fin digitedatos
    
}//fin checkin
