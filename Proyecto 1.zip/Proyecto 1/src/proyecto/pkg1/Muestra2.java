/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto.pkg1;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;


/**
 *
 * @author aaron
 */
public class Muestra2 extends JFrame {

    Destino miDest = new Destino();
    Reserva miReser = new Reserva();
    String[] vector2 = miReser.llenaV();

    public Muestra2() {
        setSize(500, 500); //tamano ventana 

        setDefaultCloseOperation(EXIT_ON_CLOSE); // Termina ventana
        setTitle("Reservacion");
        setLocationRelativeTo(null); // ventana en centro 
    }

    public void initComponents() {
        JPanel panel = new JPanel(); // crea panel
        panel.setLayout(null);
        this.getContentPane().add(panel);

        JLabel etiqueta = new JLabel();
        etiqueta.setText("Pasaporte: " + miReser.vector[0]);
        etiqueta.setBounds(10, 10, 100, 20);
        panel.add(etiqueta);

        JLabel etiqueta1 = new JLabel();
        etiqueta1.setText("Nombre: " + miReser.vector[1]);
        etiqueta1.setBounds(10, 30, 100, 20);
        panel.add(etiqueta1);

        JLabel etiqueta2 = new JLabel();
        etiqueta2.setText("Apellido: " + miReser.vector[2]);
        etiqueta2.setBounds(10, 50, 100, 20);
        panel.add(etiqueta2);

        JLabel etiqueta3 = new JLabel();
        etiqueta3.setText("Edad: " + miReser.vector[3]);
        etiqueta3.setBounds(10, 70, 100, 20);
        panel.add(etiqueta3);

        JLabel etiqueta4 = new JLabel();
        etiqueta4.setText("Correo: " + miReser.vector[4]);
        etiqueta4.setBounds(10, 90, 100, 20);
        panel.add(etiqueta4);

        JLabel etiqueta5 = new JLabel();
        etiqueta5.setText("Celular: " + miReser.vector[5]);
        etiqueta5.setBounds(10, 110, 100, 20);
        panel.add(etiqueta5);

        JLabel etiqueta6 = new JLabel();
        etiqueta6.setText("Usuario: " + miReser.vector[6]);
        etiqueta6.setBounds(10, 130, 100, 20);
        panel.add(etiqueta6);

        JLabel etiqueta7 = new JLabel();
        etiqueta7.setText("Destino: " + miDest.dest);
        etiqueta7.setBounds(10, 150, 100, 20);
        panel.add(etiqueta7);

        JLabel etiqueta8 = new JLabel();
        etiqueta8.setText("Dias: " + miDest.cantDias);
        etiqueta8.setBounds(10, 170, 100, 20);
        panel.add(etiqueta8);

        JLabel etiqueta9 = new JLabel();
        etiqueta9.setText("Total a pagar: " + miDest.total);
        etiqueta9.setBounds(10, 190, 100, 20);
        panel.add(etiqueta9);

    }// fin init

}
